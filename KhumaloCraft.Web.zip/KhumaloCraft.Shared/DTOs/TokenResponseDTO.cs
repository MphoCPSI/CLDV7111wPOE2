namespace KhumaloCraft.Shared.DTOs;

public class TokenResponseDTO
{
  public string Token { get; set; }
}
