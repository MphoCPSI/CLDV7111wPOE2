namespace KhumaloCraft.Shared.DTOs;
public class CartLinkDTO
{
  public string cartId { get; set; }
  public string userId { get; set; }
}