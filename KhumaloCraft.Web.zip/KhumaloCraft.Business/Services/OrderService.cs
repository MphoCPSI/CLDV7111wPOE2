using KhumaloCraft.Business.Interfaces;
using KhumaloCraft.Data.Entities;
using KhumaloCraft.Data.Repositories.Interfaces;
using KhumaloCraft.Shared.DTOs;

namespace KhumaloCraft.Business.Services;

public class OrderService : IOrderService
{
  private readonly IOrderRepository _orderRepository;

  public OrderService(IOrderRepository orderRepository)
  {
    _orderRepository = orderRepository;
  }

  public async Task<List<OrderDTO>> GetAllOrders()
  {
    var orders = await _orderRepository.GetAllOrdersAsync();

    var orderDTOs = orders.Select(p => new OrderDTO()).ToList();

    return orderDTOs;
  }

  public async Task<OrderDTO?> GetOrderById(int orderId)
  {
    var order = await _orderRepository.GetOrderByIdAsync(orderId);
    if (order == null) return null;

    return new OrderDTO();
  }

  public async Task AddOrder(OrderDTO orderDTO)
  {
    var order = new Order
    {
      UserId = orderDTO.UserId,
      OrderDate = DateTime.Now,
    };

    foreach (var itemDTO in orderDTO.Items)
    {
      var orderItem = new OrderItem
      {
        ProductId = itemDTO.ProductId,
        Quantity = itemDTO.Quantity,
      };

      order.OrderItems.Add(orderItem);
    }

    await _orderRepository.AddOrderAsync(order);
    await _orderRepository.SaveChangesAsync();
  }

  public async Task CancelOrder(int orderId)
  {
    var order = await _orderRepository.GetOrderByIdAsync(orderId);
    if (order == null) return;

    await _orderRepository.CancelOrderAsync(order);
    await _orderRepository.SaveChangesAsync();
  }
}
