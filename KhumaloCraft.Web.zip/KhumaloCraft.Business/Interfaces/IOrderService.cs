using KhumaloCraft.Shared.DTOs;

namespace KhumaloCraft.Business.Interfaces;

public interface IOrderService
{
  Task<List<OrderDTO>> GetAllOrders();
  Task<OrderDTO?> GetOrderById(int orderId);
  Task AddOrder(OrderDTO orderDTO);
  Task CancelOrder(int orderId);
}
