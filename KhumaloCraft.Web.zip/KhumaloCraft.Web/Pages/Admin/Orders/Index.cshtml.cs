using System.Text.Json;
using KhumaloCraft.Shared.DTOs;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace KhumaloCraft.Web.Pages.Admin.Orders
{
  public class IndexModel : PageModel
  {
    private readonly HttpClient _httpClient;
    public OrderDTO Order { get; set; } = new OrderDTO();

    public IndexModel(IHttpClientFactory httpClientFactory)
    {
      _httpClient = httpClientFactory.CreateClient("BusinessAPI");
    }

    public async Task OnGetAsync()
    {
      var response = await _httpClient.GetAsync($"api/orders");

      if (response.IsSuccessStatusCode)
      {
        var jsonResponse = await response.Content.ReadAsStringAsync();

        Order = JsonSerializer.Deserialize<OrderDTO>(jsonResponse, new JsonSerializerOptions
        {
          PropertyNameCaseInsensitive = true
        });
      }
      else
      {
        Order = new OrderDTO();
      }
    }
  }
}
