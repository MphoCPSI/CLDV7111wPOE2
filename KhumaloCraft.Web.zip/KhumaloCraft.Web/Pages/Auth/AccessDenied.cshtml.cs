using Microsoft.AspNetCore.Mvc.RazorPages;

namespace KhumaloCraft.Web.Pages.Auth
{
    public class AccessDeniedModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
